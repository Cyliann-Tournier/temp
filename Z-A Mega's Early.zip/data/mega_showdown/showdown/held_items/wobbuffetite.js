{
  name: "wobbuffetite",
  spritenum: 666,
  megaStone: "Wobbuffet-Mega",
  megaEvolves: ["Wobbuffet"],
  itemUser: ["Wobbuffet"],
  onTakeItem(item, source) {
    if (item.megaEvolves === source.baseSpecies.baseSpecies) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past",
}